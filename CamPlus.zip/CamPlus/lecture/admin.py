from django.contrib import admin
from lecture.models import timetable
# Register your models here.

admin.site.register(timetable)
