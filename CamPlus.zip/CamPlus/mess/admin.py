from django.contrib import admin
from mess.models import menu
# Register your models here.
admin.site.register(menu)
