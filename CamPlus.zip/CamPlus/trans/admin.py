from django.contrib import admin
from trans.models import buswd,buswe

# Register your models here.
admin.site.register(buswd)
admin.site.register(buswe)
